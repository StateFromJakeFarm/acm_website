#include <iostream>
#include <cmath>
#include <cstdio>

using namespace std;

int main() {
    int T;
    cin >> T;

    long N, M;
    for (int t=0; t<T; t++) {
        cin >> N >> M;

        long max_edges = N*(N-1)/2;

        // Binary search for max k
        long l = 1;
        long r = max_edges;
        long k;
        while (l <= r) {
            k = (l + r) / 2;
            long edges_needed = floor( (k-1) * powl(N, 2)/(2*k) );
            if (edges_needed == M) {
                break;
            } else if (edges_needed > M) {
                r = k-1;
            } else {
                l = k+1;
            }
        }
        cout << k << endl;
    }

    return 0;
}
